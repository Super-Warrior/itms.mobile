define(function () {
   var url = "http://211.144.85.15:8080/itms/rest/";

   return {
      baseUrl: url,
      userName: "test@blade.com",
      password: "test"
    
   };
});