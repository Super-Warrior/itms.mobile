define(function () {
    return{
       eventTypes: [
           {
              name: '接单确认',
              value: "EVTNA3"
           },
           {
              name: '执行完成',
              value: "EVTNA4"
           }
       ]

    };
})